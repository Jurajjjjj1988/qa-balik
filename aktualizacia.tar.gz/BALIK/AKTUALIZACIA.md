# Aktualizácia — rozbaľ cez existujúci BALIK

Prepíše **5 vecí**, zvyšok necháva tak.

| súbor | čo je nové |
| --- | --- |
| **`POSTUP.md`** | 🆕 pracovná slučka, 8 krokov s výstupnými podmienkami |
| `ZACNI-TU.md` | slučka **priamo v primeri** — vkladá sa každú session |
| `STRATEGIA.md` | fáza 1: odkaz na nameraný rozsah v `~/Cat-knowledge/measurements/` |
| `skilly/qa-matrices-and-docs/` | skrátené; popis pod strop 1 536 *(orezával sa)* |
| `skilly/sql-validation-mysql-mssql/` | 🆕 sekcia **„Spusti"** s exit kódmi; popis pod strop |

## Prečo tie dva popisy

Boli **1 680 a 1 793 znakov**. Strop v listingu skillov je **1 536** — takže sa
orezávali už pri načítaní. `sql-validation-mysql-mssql` prichádzal o **11 zo 14
spúšťacích fráz** aj o vetu *„nepoužívaj na SQL Server vs PostgreSQL"*.

Teraz **1 450 a 1 470**.

## A jedna vec, čo v skille chýbala

`sql-validation-mysql-mssql` sľuboval sondu, ale **telo ju ani raz nezavolalo** —
model ju nemal ako nájsť. Pribudla sekcia „Spusti":

| exit | znamená |
| :---: | --- |
| 0 | zmerané |
| 1 | spojenie nefunguje |
| 2 | zlé argumenty |
| **3** | 🔴 **sonda nedôveryhodná — celý výstup zahodiť** |
